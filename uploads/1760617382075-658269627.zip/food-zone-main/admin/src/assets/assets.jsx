import add_icon from './add_icon.jpg';
import logo from './logo.jpg';
import order_icon from './order_icon.jpg';
import parcel_icon from './parcel_icon.jpg';
import upload_icon from './upload_icon.jpg';
import user_icon from './user_icon.jpg';
import Feedback from './feedback.jpg';
import list from './list.jpg';

export const assets ={
    add_icon,
    list,
    logo,
    user_icon,
    order_icon,
    parcel_icon,
    upload_icon,
    Feedback
}